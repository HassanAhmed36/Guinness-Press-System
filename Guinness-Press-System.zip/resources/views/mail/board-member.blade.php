<p>Request To Join Editorial Board</p>

<strong>Journal Name:</strong> {{$data["journal_name"]}}  <br>
<strong>Customer Name:</strong>  {{$data["name"]}} <br>
<strong>Email:</strong> {{$data["email"]}} <br>
<strong>Affiliation:</strong> {{$data["affiliation"]}}  <br>
<strong>Scopus ID:</strong> {{$data["scopus_id"]}} <br>
<strong>Scholar ID:</strong> {{$data["scholar_id"]}} <br>
<strong>Biography:</strong> {{$data["biography"]}}  <br>
