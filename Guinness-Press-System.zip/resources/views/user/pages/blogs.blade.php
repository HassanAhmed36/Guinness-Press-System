@extends('user.layouts.template')

@section('title', 'Home Page')

@section('banner')
    <section class="main_banner inner_banner">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="banner_content white_text">
                        <h3 class="cocogoose_light">
                            aBOUT uS
                        </h3>
                        <h1 class="cocogoose_light">
                            About Guinness Press
                        </h1>
                        <p class="poppins_fonts">
                            Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod
                            tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis
                            nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
@endsection
@section('body')
@endsection
