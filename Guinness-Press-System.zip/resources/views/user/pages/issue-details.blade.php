@extends('user.layouts.template')

@section('title', 'Home Page')

@section('body')
@endsection
