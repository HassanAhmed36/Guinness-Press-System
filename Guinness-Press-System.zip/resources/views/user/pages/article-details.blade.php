@extends('user.layouts.template')
@section('title', 'Home Page')
@section('banner')
@endsection
@section('body')
@endsection
